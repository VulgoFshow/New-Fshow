#!/bin/zsh

haxe test-web.hxml
