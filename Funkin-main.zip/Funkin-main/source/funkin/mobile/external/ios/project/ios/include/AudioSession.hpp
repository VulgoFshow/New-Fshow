#pragma once

void initialize();
void setActive(bool active);
